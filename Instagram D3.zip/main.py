import json
import os
import time
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
import pwinput

console = Console()

def clearConsole():
    os.system('cls' if os.name == 'nt' else 'clear')

def uniqueUsername(username):
    user_names = []
    file_name = 'users.json'
    with open(file_name, 'r') as file:
        users = json.load(file)
        for user in users:
            user_names.append(user['Username'])
    return (not username in user_names)

def checkPassword(username, password):
    file_name = 'users.json'
    with open(file_name, 'r') as file:
        users = json.load(file)
        for user in users:
            if user['Username'] == username:
                return user['Password'] == password
    return False

def Messaging(username):
    with open('users.json', 'r') as f:
        users = json.load(f)

    with open('messages.json', 'r') as f:
        messages = json.load(f)

    while True:
        clearConsole()

        console.print("[bold blue]Messages[/bold blue]")

        inbox = [msg for msg in messages if 'Receiver' in msg and msg['Receiver'].strip() == username]
        outbox = [msg for msg in messages if 'Sender' in msg and msg['Sender'].strip() == username]

        console.print("[bold green]Inbox:[/bold green]")

        if not inbox:
            console.print("[italic yellow]No messages.[/italic yellow]")

        else:
            for i, msg in enumerate(inbox, 1) : 
                likes = len(msg.get('Likes', []))

                console.print(f"[{i}] From @{msg['Sender'].strip()} - {msg['Text'].strip()} [{msg['Time Stamp']}] [Likes: {likes}]")

        console.print("[bold green]Outbox:[/bold green]")

        if not outbox:
            console.print("[italic yellow]No sent messages.[/italic yellow]")

        else:
            for i, msg in enumerate(outbox, len(inbox) + 1 ):  
                likes = len(msg.get('Likes', []))

                console.print(f"[{i}] To @{msg['Receiver'].strip()} - {msg['Text'].strip()} [{msg['Time Stamp']}] [Likes: {likes}]")

        choice = int(input('''
1. Send message
2. Like message
3. Back
'''))

        if choice == 1 :
            receiver = input("Enter receiver username: ")

            found = False
            for u in users:
                if u['Username'] == receiver:
                    found = True
                    break

            if not found:
                console.print("[red]User not found.[/red]")
                time.sleep(2)
                continue

            text = input("Message: ")

            messages.append({
                "Sender": username,
                "Receiver": receiver,
                "Text": text,
                "Time Stamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "Likes": []
            })

            with open('messages.json', 'w') as f:
                json.dump(messages, f, indent=2)

            console.print("[green]Message sent successfully![/green]")

            time.sleep(2)

        elif choice == 2:
            messageId = int(input("Enter Message ID: "))

            myMessages = inbox + outbox

            if messageId < 1 or messageId > len(myMessages):
                console.print("[red]Invalid message number![/red]")
                time.sleep(2)
                continue

            message = myMessages[messageId - 1]

            if username not in message.get('Likes', []):
                message.setdefault('Likes', []).append(username)
                console.print(f"[green]You liked this message![/green]\n[bold]Message:[/bold] {message['Text']} [bold]From:[/bold] @{message['Sender']} [bold]To:[/bold] @{message['Receiver']}")
            else:
                console.print("[yellow]You already liked this message![/yellow]")

            with open('messages.json', 'w') as f:
                json.dump(messages, f, indent=2)

            time.sleep(2)

        elif choice == 3:
            UserMenu(username)  

        else:
            console.print("[red]Invalid choice![/red]")
            time.sleep(2)



def CheckTaggedPosts(username):
    with open('posts.json', 'r') as f:
        posts = json.load(f)

    tagged_posts = []
    for p in posts:
        for comment in p['Comments']:
            if f"@{username}" in comment['Text']:
                tagged_posts.append(p)

    if tagged_posts:
        console.print(f"[bold yellow]You were tagged in {len(tagged_posts)} post(s):[/bold yellow]")

        for post in tagged_posts:
            console.print(Panel(f"""
@{post['Owner']}
"{post['Caption']}"
{post['Timestamp']}
""", title=f"Tagged Post ID: {post['PostID']}", border_style="yellow", expand = False, width = 100))
            
        input("Press Enter")

def UserMenu(username):
    while True:

        clearConsole()

        CheckTaggedPosts(username) 

        choose = int(input('''
Where do you want to go?
1. Profile
2. Home
3. Stories
4. Explore
5. Messages
6. Log Out
'''))
        
        if choose == 1 :
            Profile(username)
        elif choose == 2 :
            Home(username)
        elif choose == 3 :
            Stories(username)
        elif choose == 4 :
            Explore(username)
        elif choose == 5:
            Messaging(username)
        else :
            console.print("[red]You logged out successfully![/red]")

            time.sleep(2)

            Start()

        break

def Home(username):
    with open('users.json', 'r') as f:
        users = json.load(f)

    with open('posts.json', 'r') as f:
        posts = json.load(f)

    myUser = None
    for user in users:
        if user['Username'] == username:
            myUser = user

    followings = myUser.get("Followings", [])

    while True:

        clearConsole()

        console.print("[bold blue]Home[/bold blue]")

        showPosts = []
        for p in posts:
            if isinstance(p, dict):
                owner = p.get('Owner')
                if owner in followings or owner == username:
                    showPosts.append(p)

        if not showPosts:
            console.print("[italic red]No posts to show yet.[/italic red]")

        else:
            for post in showPosts[::-1]:
                caption = post['Caption']
                likes = len(post['Likes'])
                comments = len(post['Comments'])
                saves = len(post['Saves'])
                shares = post['Shares']
                timestamp = post['Timestamp']

                console.print(Panel(f"""
@{post['Owner']}
"{caption}"
{likes} Likes    {comments} Comments    {saves} Saves    {shares} Shares
{timestamp}
""", title=f"Post ID: {post['PostID']}", border_style="purple", expand = False, width = 100))

        choice = int(input('''
1. Like
2. Comment
3. Save
4. Share
5. Create new post
6. Back to Menu
'''))

        if choice == 1 or choice == 2 or choice == 3 or choice == 4:
            post_id = int(input("Enter Post ID: "))

            post = None
            for p in posts:
                if p['PostID'] == post_id:
                    post = p

            if not post:
                console.print("[italic red]Post not found.[/italic red]")
                time.sleep(2)
                continue

            if choice == 1 :
                if username not in post['Likes']:
                    post['Likes'].append(username)
                    console.print("[green]You liked the post.[/green]")
                else :
                    console.print("[italic yellow]You already liked this post![/italic yellow]")

            elif choice == 2 :
                text = input("Your comment: ")
                post['Comments'].append({"Username": username, "Text": text})
                console.print("[green]Comment added.[/green]")

            elif choice == 3 :
                if username not in post['Saves']:
                    post['Saves'].append(username)
                    for user in users:
                        if user['Username'] == username:
                            if post_id not in user['SavedPosts']:
                                user['SavedPosts'].append(post_id)
                                break

                   
                    console.print("[green]Post saved.[/green]")
                    
                    with open('users.json', 'w') as file:
                        json.dump(users, file, indent=2)
               
                else :
                    console.print("[italic yellow]You already saved this post![/italic yellow]")


            elif choice == 4 :
                post['Shares'] += 1
                console.print("[green]Post shared.[/green]")

            with open('posts.json', 'w') as file:
                json.dump(posts, file, indent=2)

            time.sleep(2)

        elif choice == 5 :
            caption = input("Caption: ")
            new_post = {
                "PostID": max([p['PostID'] for p in posts], default=0) + 1,
                "Owner": username,
                "Caption": caption,
                "Likes": [],
                "Comments": [],
                "Saves": [],
                "Shares": 0,
                "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M")
            }

            posts.append(new_post)

            with open('posts.json', 'w') as file:
                json.dump(posts, file, indent=2)

            console.print("[green]You upload a Post!.[/green]")
            time.sleep(2)

        else :
           UserMenu(username)

def Stories(username):
    storiesFile = 'stories.json'
    storisData = []
    while True:
        clearConsole()
        console.print("[bold blue]Stories[/bold blue]")
        choice = int(input('''
1. View Stories
2. Add Story
3. Back 
'''))          
                           
        if choice == 1 :
            with open('users.json', 'r') as f:
                users = json.load(f)

            myUser = None
            for user in users:
                if user['Username'] == username:
                    myUser = user
                    break

            if not myUser:
                console.print("[red]User not found.[/red]")
                return
            
            following = myUser.get("Followings", [])

            with open('stories.json', 'r') as f:
                storisData = json.load(f)

            clearConsole()

            console.print("[bold blue]Viewing Stories[/bold blue]")

            foundStory = False

            for story in storisData:
                if story.get("Owner") in following or story.get("Owner") == username:
                    console.print(Panel(f"""
@{story['Owner']}                                                             
{story['Content']}                                       
{story['Timestamp']}
""", title="Story", border_style="purple", expand = False, width = 100))
                    
                    foundStory = True

                    action = int(input("""
1. Like Story
2. Share Story
3. Next Story
"""))
                    if action == 1 :
                        story.setdefault("Likes", []).append(username)
                        console.print("[green]You liked the story![/green]")

                    elif action == 2 :
                        story["Shares"] = story.get("Shares", 0) + 1
                        console.print("[green]You shared the story![/green]")

                    elif action == 3 :
                        continue

            if not foundStory:
                console.print("[italic yellow]No stories available.[/italic yellow]")

            with open('stories.json', 'w') as f:
                json.dump(storisData, f, indent=2)

            input("Press Enter")

        elif choice == 2 :
            content = input("Story content: ")

            with open('stories.json', 'r') as f:
                storisData = json.load(f)

            newStory = {
                "Story id": len(storisData) + 1,
                "Owner": username,
                "Content": content,
                "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
                "Likes": [],
                "Shares": 0
            }

            storisData.append(newStory)

            with open('stories.json', 'w') as f:
                json.dump(storisData, f, indent=2)

            console.print("[green]Story added successfully![/green]")
            time.sleep(2)

        else:
            UserMenu(username)
            break

def Profile(username):
    with open('users.json', 'r') as f:
        users = json.load(f)

    with open('posts.json', 'r') as f:
        posts = json.load(f)

    with open('stories.json', 'r') as f:
        stories = json.load(f)

    myUser = None
    for user in users:
        if user['Username'] == username:
            myUser = user
            break

    if not myUser:
        console.print("[red]User not found.[/red]")
        return

    userPosts = [post for post in posts if post['Owner'] == username]
    userStories = [story for story in stories if story['Owner'] == username]

    while True:
        clearConsole()
        name = myUser.get("Name", "Not set")
        bio = myUser.get("Bio", "No bio")
        followers = len(myUser.get("Followers", []))
        followings = len(myUser.get("Followings", []))
        isPrivate = "Private" if myUser.get("Private", False) else "Public"
        savedPosts = myUser.get("SavedPosts", [])
        blockedUsers = myUser.get("BlockedList", [])

        panel = Panel(f"""
[bold blue]@{username}[/bold blue]
[bold]Name:[/bold] {name}
[bold]Bio:[/bold] {bio}
[bold]Posts:[/bold] {len(userPosts)} , [bold]Followers:[/bold] {followers} , [bold]Following:[/bold] {followings}
[bold]Account Type:[/bold] {isPrivate}
[bold]Saved Posts:[/bold] {len(savedPosts)} posts
[bold]Blocked Users:[/bold] {len(blockedUsers)} users
[bold purple]Choose an option:[/bold purple]
1. Edit name or username
2. Edit password
3. Edit bio
4. Edit email
5. Saved posts
6. Change privacy setting
7. View blocked users or Unblock users
8. View posts
9. View stories
10. Back to menu
""", title="Profile", border_style="bold blue", expand = False, width = 100)
        
        console.print(panel)

        choice = int(input())
        if choice == 1 :
            newName = input("Enter your new name: ")
            newUsername = input("Enter new username (leave empty for no change): ")

            if newUsername and not uniqueUsername(newUsername):
                console.print("[red]Username already taken![/red]")

            else:
                myUser["Name"] = newName
                if newUsername:
                    myUser["Username"] = newUsername
                    username = newUsername

                with open('users.json', 'w') as file:
                    json.dump(users, file, indent=2)

                console.print("[green]Name or Username updated successfully![/green]")
                time.sleep(2)

        elif choice == 2 :  
            currentPassword = pwinput.pwinput("Enter your current password: ")

            if not checkPassword(username, currentPassword):
                console.print("[red]Incorrect password![/red]")
                time.sleep(2)

            else:
                newPassword = pwinput.pwinput("Enter your new password: ")
                confirmPassword = pwinput.pwinput("Confirm your new password: ")

                if newPassword != confirmPassword:
                    console.print("[red]Oops! Passwords don't match![/red]")
                    time.sleep(2)

                else:
                    myUser["Password"] = newPassword

                    with open('users.json', 'w') as file:
                        json.dump(users, file, indent=2)

                    console.print("[green]Password updated successfully![/green]")

                    time.sleep(2)

        elif choice == 3 :
            newBio = input("Bio: ")
            myUser["Bio"] = newBio

            with open('users.json', 'w') as file:
                json.dump(users, file, indent=2)

            console.print("[green]Bio updated successfully![/green]")
            time.sleep(2)

        elif choice == 4 :  
                    newEmail = input("Enter your new email: ")
                    myUser["Email"] = newEmail

                    with open('users.json', 'w') as file:
                        json.dump(users, file, indent=2)

                    console.print("[green]Email updated successfully![/green]")
                    time.sleep(2)

        elif choice == 5 :
            console.print("[bold cyan]Saved Posts:[/bold cyan]")

            if not savedPosts:
                console.print("[italic yellow]You have no saved posts.[/italic yellow]")
            else:
                with open('posts.json', 'r') as f:
                    posts = json.load(f)

                saved_posts_details = [post for post in posts if post['PostID'] in savedPosts]

                if not saved_posts_details:
                    console.print("[italic yellow]No saved posts found in the database.[/italic yellow]")
                else:

                    for post in saved_posts_details:
                        owner = post['Owner']
                        caption = post['Caption']
                        likes = len(post['Likes'])
                        comments = len(post['Comments'])
                        saves = len(post['Saves'])
                        shares = post['Shares']
                        timestamp = post['Timestamp']

                        console.print(Panel(f"""
@{owner}
{caption}
{likes} Likes     {comments} Comments     {saves} Saves     {shares} Shares
{timestamp}
""", title=f"Post ID: {post['PostID']}", border_style="green", expand = False, width = 100))

            input("Press Enter")

        elif choice == 6 :
            if myUser["Private"]:
                myUser["Private"] = False

            else:
                myUser["Private"] = True

            with open('users.json', 'w') as file:
                json.dump(users, file, indent=2)

            status = "Private" if myUser["Private"] else "Public"
            console.print(f"[green]Your account is now {status}.[/green]")

            time.sleep(2)

        elif choice == 7 :
            if not blockedUsers:
                console.print("[italic yellow]No blocked users.[/italic yellow]")

            else:
                console.print("[bold cyan]Blocked Users:[/bold cyan]")
                for i, user in enumerate(blockedUsers, 1):
                    console.print(f"{i}. {user}")

                unblock = input("Enter username for unblock: ")

                if unblock in blockedUsers:
                    myUser["BlockedList"].remove(unblock)
                    console.print(f"[green]User @{unblock} unblocked.[/green]")

                    with open('users.json', 'w') as file:
                        json.dump(users, file, indent=2)

            input("Press Enter")

        elif choice == 8 :
            console.print("[bold cyan]Your Posts:[/bold cyan]")

            if not userPosts:
                console.print("[italic yellow]You have no posts.[/italic yellow]")

            else:
                for post in userPosts[::-1]:
                    caption = post['Caption']
                    likes = len(post['Likes'])
                    comments = len(post['Comments'])
                    saves = len(post['Saves'])
                    shares = post['Shares']
                    timestamp = post['Timestamp']

                    console.print(Panel(f"""
{caption}
{likes} Likes     {comments} Comments     {saves} Saves     {shares} Shares
{timestamp}
""", title=f"Post ID: {post['PostID']}", border_style="green", expand = False, width = 100))
            input("Press Enter")

        elif choice == 9 :
            console.print("[bold cyan]Your Stories:[/bold cyan]")

            if not userStories:
                console.print("[italic yellow]You have no stories.[/italic yellow]")

            else:
                for story in userStories:
                    content = story['Content']
                    timestamp = story['Timestamp']
                    likes = len(story.get('Likes', []))
                    shares = story.get('Shares', 0)

                    console.print(Panel(f"""
{content}
{timestamp}
Likes: {likes}    Shares: {shares}
""", title="Story", border_style="purple", expand = False, width = 100))
            input("Press Enter")

        else:
            UserMenu(username)
            break

def Explore(username):
    with open('users.json', 'r') as f:
        users = json.load(f)

    with open('posts.json', 'r') as f:
        posts = json.load(f)

    with open('stories.json', 'r') as f:
        stories = json.load(f)

    while True:  
        clearConsole()
        console.print("[bold blue]Explore[/bold blue]")
        search = input("Enter a username for search (enter for back): ").strip()
        if search.lower() == '':
            return UserMenu(username) 

        user = None
        for u in users:
            if u['Username'] == search:
                user = u
                break

        if user is None:
            console.print("[italic red]No user was found.[/italic red]")
            input("Press Enter")
            continue

        if username in user.get("BlockedList", []):
            console.print("[italic red]You are blocked by this user.[/italic red]")
            input("Press Enter")
            continue

        postUser = 0
        for post in posts:
            if post['Owner'] == user['Username']:
                postUser += 1

        followers = len(user.get("Followers", []))
        followings = len(user.get("Followings", []))
        bio = user.get("Bio", "No bio")
        isPrivate = user.get("Private", False)

        console.print(Panel(f"""
Username: @{user['Username']}
Bio: {bio}
Account Type: {'Private' if isPrivate else 'Public'}
Posts: {postUser} , Followers: {followers} , Following: {followings}
""", title="Profile", border_style="purple", expand = False, width = 100))

        myUser = None
        for u in users:
            if u['Username'] == username:
                myUser = u
                break

        if user['Username'] in myUser['Followings']:
            print("1. Unfollow this user")
            print("2. Block this user")
        elif user['Username'] in myUser['BlockedList']:
            print("1. Unblock this user")
        else:
            print("1. Follow this user")
            print("2. Block this user")

        if (not isPrivate) or (username in user.get("Followers", [])):
            print("3. View posts")
            print("4. View stories")

        print("5. Back")
        choice = int(input())

        if choice == 1:
            if user['Username'] in myUser['Followings']:
                myUser['Followings'].remove(user['Username'])

                if username in user.get("Followers", []):
                    user['Followers'].remove(username)

                console.print("[green]You unfollowed this user![/green]")

            elif user['Username'] in myUser['BlockedList']:
                myUser['BlockedList'].remove(user['Username'])
                console.print("[green]User unblocked![/green]")

            else:
                if not user['Private']:
                    myUser['Followings'].append(user['Username'])
                    user['Followers'].append(myUser['Username'])
                    console.print("[green]You are now following this user.[/green]")

                else:
                    if username not in user.get("Follow Requests", []):
                        user.setdefault("Follow Requests", []).append(username)
                        console.print("[yellow]Follow request sent![/yellow]")

                    else:
                        console.print("[italic]You have already sent a request.[/italic]")

            with open('users.json', 'w') as file:
                json.dump(users, file, indent=2)

            time.sleep(2)

        elif choice == 2 and user['Username'] not in myUser['BlockedList']:
            myUser['BlockedList'].append(user['Username'])
            console.print("[red]User blocked![/red]")

            with open('users.json', 'w') as file:
                json.dump(users, file, indent=2)

            time.sleep(2)

        elif choice == 3 and ((not isPrivate) or (username in user.get("Followers", []))):
            userPosts = [p for p in posts if p['Owner'] == user['Username']]

            if not userPosts:
                console.print("[italic yellow]This user has no posts.[/italic yellow]")
                input("Press Enter")
                continue

            while True:
                clearConsole()
                console.print(f"[bold cyan]@{user['Username']}'s posts[/bold cyan]\n")
                for post in userPosts[::-1]:
                    caption = post['Caption']
                    likes = len(post['Likes'])
                    comments = len(post['Comments'])
                    saves = len(post['Saves'])
                    shares = post['Shares']
                    timestamp = post['Timestamp']

                    console.print(Panel(f"""
{caption}
{likes} Likes     {comments} Comments     {saves} Saves     {shares} Shares
{timestamp}
""", title=f"Post ID: {post['PostID']}", border_style="green", expand = False, width = 100))

                choose = int(input('''  
1. Like a post
2. Comment on a post
3. Save a post
4. Share a post
5. Back
'''))

                if choose == 5:
                    break

                if choose not in [1, 2, 3, 4]:
                    console.print("[red]Invalid choice.[/red]")
                    time.sleep(1)
                    continue

                try:
                    post_id = int(input("Enter Post ID: "))
                except ValueError:
                    console.print("[red]Invalid Post ID.[/red]")
                    time.sleep(1)
                    continue

                post = None
                for p in posts:
                    if p['PostID'] == post_id and p['Owner'] == user['Username']:
                        post = p
                        break
                if not post:
                    console.print("[red]Post not found.[/red]")
                    time.sleep(1)
                    continue

                if choose == 1:
                    if username not in post['Likes']:
                        post['Likes'].append(username)
                        console.print("[green]You liked the post![/green]")

                    else:
                        console.print("[yellow]You already liked this post![/yellow]")

                elif choose == 2:
                    comment = input("Your comment: ")
                    post['Comments'].append({"Username": username, "Text": comment})
                    console.print("[green]Comment added.[/green]")

                elif choose == 3:
                    if username not in post['Saves']:
                        post['Saves'].append(username)

                        for user in users:
                            if user['Username'] == username:
                                if post_id not in user['SavedPosts']:
                                    user['SavedPosts'].append(post_id)
                                    break

                        console.print("[green]Post saved.[/green]")

                        with open('users.json', 'w') as file:
                            json.dump(users, file, indent=2)

                    else:
                        console.print("[yellow]You already saved this post.[/yellow]")

                elif choose == 4:
                    post['Shares'] += 1
                    console.print("[green]Post shared.[/green]")

                with open('posts.json', 'w') as file:
                    json.dump(posts, file, indent=2)

                time.sleep(2)

        elif choice == 4 and ((not isPrivate) or (username in user.get("Followers", []))):
            userStories = [s for s in stories if s.get('Owner') == user['Username']]

            if not userStories:
                console.print("[italic yellow]This user has no stories.[/italic yellow]")
                input("Press Enter")
                continue

            clearConsole()
            console.print(f"[bold cyan]@{user['Username']}'s stories[/bold cyan]")

            for story in userStories:
                content = story.get('Content', 'No content')
                timestamp = story.get('Timestamp', 'No timestamp')
                likes = len(story.get('Likes', []))
                shares = story.get('Shares', 0)

                console.print(Panel(f"""
{content}
{timestamp}
Likes: {likes}    Shares: {shares}
""", title="Story", border_style="purple", expand = False, width = 100))

                action = int(input('''
1. Like Story
2. Share Story
3. Next Story
'''))
                if action == 1:
                    story.setdefault("Likes", []).append(username)
                    console.print("[green]You liked the story![/green]")

                elif action == 2:
                    story["Shares"] = story.get("Shares", 0) + 1
                    console.print("[green]You shared the story![/green]")

                elif action == 3:
                    continue

            with open('stories.json', 'w') as f:
                json.dump(stories, f, indent=2)

            input("Press Enter to go back.")

        elif choice == 5:
            return
        
def Login():
    console.print("[bold][blue]Login:[/bold][/blue]")
    while True:
        username = input("Username: ")
        password = pwinput.pwinput("Password: ")

        if not checkPassword(username, password):
            console.print("[red]Invalid username or password.[/red]")

        else:
            console.print(f"[green]You logged in as @{username} successfully![/green]")

            time.sleep(2)

            UserMenu(username)

def Signup():
    console.print("[bold][blue]Signup:[/bold][/blue]")

    while True:
        username = input("Username: ")
        if not uniqueUsername(username):
            console.print("[red]The username was taken.[/red]")

        else:
            break

    email = input("Email: ")
    password = pwinput.pwinput("Password: ")
    name = input("Full name: ")
    bio = input("Bio: ")

    new_user = {
        'Username': username,
        'Email' : email,
        'Password': password,
        'Name': name,
        'Bio': bio,
        'Private': False,
        'Follow Requests':[],
        'Followings': [],
        'Followers': [],
        'BlockedList': [],
        'SavedPosts': []   
    }

    with open('users.json', 'r') as file:
        users = json.load(file)

    users.append(new_user)

    with open('users.json', 'w') as file:
        json.dump(users, file, indent=2)

    console.print(f"[green]You signed up as @{username} successfully![/green]")

    time.sleep(2)
    
    UserMenu(username)

def Start() :
    while True:
        clearConsole()
        choice = int(input('''
What do you want to do?
1. Login
2. Signup
3. Exit
'''))
        

        if choice == 1 :
            Login()

        elif choice == 2 :
            Signup()
            
        else :
            console.print("[bold red]Exit![/bold red]")
            exit()
            break

Start()